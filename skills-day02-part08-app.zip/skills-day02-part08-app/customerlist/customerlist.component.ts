import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {
  customerList$: Observable<any>;
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.customerList$ = this.http.get("http://localhost:3000/customers");
  }
}
