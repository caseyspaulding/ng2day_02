import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { map } from 'rxjs/operators';
//
interface Employee{
  username : String;
  password : String;
};
//
@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
  employeeList$: Observable<Employee[]>;
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.employeeList$ = this.http.get<Employee[]>("http://localhost:3000/employees")
  }
}
